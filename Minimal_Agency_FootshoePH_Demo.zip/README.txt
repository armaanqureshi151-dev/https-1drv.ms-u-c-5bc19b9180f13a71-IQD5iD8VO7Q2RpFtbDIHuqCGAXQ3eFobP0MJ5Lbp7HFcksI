MINIMAL AGENCY — FOOTSHOEPH DEMO

Open index.html in a browser to preview the demo.

This is a sales-demo concept, not a live store. Product names, prices and operational claims are placeholders and should be replaced with the client's real catalogue/details before publishing.

The key pitch is the AI Shopping Concierge: an AI sales/support agent that can answer product questions, recommend items, handle FAQs and route high-intent customers to the team.

Suggested message to send with the demo:
"I made this specifically around your business so you can see what an AI-powered customer journey could look like. The AI section is the part we'd actually build and connect to your customer inquiries. If you like the concept, I can show you how we'd make it live."
