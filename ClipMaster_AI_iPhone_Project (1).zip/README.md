# ClipMaster AI — iPhone Edition

An iPhone-friendly installable PWA with a Python processing server.

## Important architecture
The iPhone is the remote-control interface. A computer or cloud server runs FFmpeg, Faster-Whisper and the processing queue. iOS Safari cannot reliably run long background recordings or FFmpeg itself.

Use this only for videos/streams you own or are authorized to record. Platform APIs, terms, copyright and creator permissions still apply. This project does not bypass DRM, paywalls, login restrictions or platform protections.

## Requirements
- Python 3.10+
- FFmpeg installed and available on PATH
- Optional: `yt-dlp` for permitted public/authorized stream URLs
- Optional: Faster-Whisper (installed through requirements)
- iPhone and server on same network, or deploy server securely with HTTPS.

## Run the server
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```
Open `http://SERVER-IP:8000` from Safari. For a public deployment use HTTPS and add authentication/reverse-proxy protection. Do not expose the unauthenticated development server to the public internet.

## iPhone Home Screen
1. Open the server URL in Safari.
2. Tap Share → Add to Home Screen.
3. Launch ClipMaster AI from the new icon.

## Workflow
### After a stream
Upload an MP4/MOV/MKV recording from Files/Photos. Tap Process. The server extracts audio, transcribes it (if Faster-Whisper is installed), scores energetic/reaction moments and renders vertical clips.

### Live mode
Paste an authorized, directly accessible live stream URL and tap Start Live Capture. The server uses yt-dlp to capture the stream while available. Stop the job from the app; then process the resulting recording. Live capture depends on source availability and platform permissions. Some YouTube/Twitch live URLs may not be capturable; use official creator tools/API or an authorized local recording in that case.

## Configuration
Copy `.env.example` to `.env` and set `CLIPMASTER_API_KEY` to a long random value. For production, implement HTTPS and authentication at a reverse proxy; the starter UI is designed for private/local network use.

## Notes
- AI transcription/highlight detection is optional and runs locally on the server.
- The included highlight ranker is a starter heuristic, not a human-level understanding model.
- Voiceover is left as an optional extension; no paid TTS API is required by this starter.
- Use licensed music only.
