import os, uuid, json, shutil, subprocess, threading, time
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
UPLOADS = DATA / "uploads"
CLIPS = DATA / "clips"
RECORDINGS = DATA / "recordings"
for p in (UPLOADS, CLIPS, RECORDINGS): p.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="ClipMaster AI")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
jobs = {}
lock = threading.Lock()

def run(cmd):
    return subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

def ffmpeg_ok():
    return shutil.which("ffmpeg") is not None

def duration(path):
    out = run(["ffprobe","-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",str(path)])
    return max(1.0,float(out.stdout.strip()))

def transcribe(path):
    try:
        from faster_whisper import WhisperModel
        model = WhisperModel(os.getenv("WHISPER_MODEL","base"), device="cpu", compute_type="int8")
        segments, _ = model.transcribe(str(path), vad_filter=True)
        return [{"start":float(s.start),"end":float(s.end),"text":s.text.strip()} for s in segments]
    except Exception as e:
        return []

def detect_highlights(path):
    # Audio energy windows are a useful starter signal; transcription adds context when available.
    wav = path.with_suffix(".wav")
    try:
        run(["ffmpeg","-y","-i",str(path),"-vn","-ac","1","-ar","16000",str(wav)])
        # ffmpeg silencedetect is used as a lightweight fallback; transcript segments are preferred.
        segments = transcribe(wav)
        if segments:
            scored=[]
            for s in segments:
                text=s["text"].lower()
                cues=sum(1 for w in ["wow","bro","no way","oh my","let's go","what","haha","laugh","crazy","insane","damn","help"] if w in text)
                scored.append((s["start"],s["end"], cues + min(len(text)/100,1), s["text"]))
            scored.sort(key=lambda x:x[2], reverse=True)
            chosen=[]
            for a,b,score,txt in scored:
                if score <= 0 and len(chosen)>=1: continue
                start=max(0,a-7); end=min(duration(path),max(b+10,start+20))
                if all(abs(start-c["start"])>18 for c in chosen):
                    chosen.append({"start":start,"end":end,"reason":txt[:110] or "Speech highlight"})
                if len(chosen)>=5: break
            if chosen: return sorted(chosen,key=lambda x:x["start"])
        # No transcription available: create evenly spaced candidate clips.
        total=duration(path)
        count=min(3,max(1,int(total//90)))
        return [{"start":max(0,(i+1)*total/(count+1)-12),"end":min(total,(i+1)*total/(count+1)+18),"reason":"Suggested moment — review manually"} for i in range(count)]
    except Exception:
        total=duration(path)
        return [{"start":0,"end":min(30,total),"reason":"First segment — review manually"}]

def render_clip(src, start, end, out):
    length=max(5,min(60,end-start))
    # Scale to fill vertical canvas, center crop; subtitles can be added in a later edit.
    vf="scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
    run(["ffmpeg","-y","-ss",str(start),"-i",str(src),"-t",str(length),"-vf",vf,"-c:v","libx264","-preset","veryfast","-crf","23","-c:a","aac","-b:a","128k","-movflags","+faststart",str(out)])

def process_file(job_id, src):
    try:
        jobs[job_id]["status"]="Analyzing"
        if not ffmpeg_ok(): raise RuntimeError("FFmpeg is not installed or not on PATH.")
        moments=detect_highlights(src)
        jobs[job_id]["status"]="Rendering"
        made=[]
        for i,m in enumerate(moments,1):
            name=f"{job_id}_{i}.mp4"; out=CLIPS/name
            render_clip(src,m["start"],m["end"],out)
            made.append({"id":name,"url":f"/clips/{name}","start":round(m["start"],1),"end":round(m["end"],1),"reason":m["reason"]})
            jobs[job_id]["progress"]=int(i/len(moments)*100)
        jobs[job_id].update(status="Completed",progress=100,clips=made)
    except Exception as e:
        jobs[job_id].update(status="Failed",error=str(e))

def capture_live(job_id, url):
    target=RECORDINGS/f"{job_id}.mp4"
    try:
        if not shutil.which("yt-dlp"): raise RuntimeError("yt-dlp is not installed.")
        jobs[job_id].update(status="Capturing",recording=str(target))
        # Only captures sources the user is authorized to access and record.
        cmd=["yt-dlp","--no-part","-o",str(target),url]
        proc=subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
        jobs[job_id]["process"]=proc
        proc.wait()
        if target.exists() and target.stat().st_size>0:
            jobs[job_id].update(status="Recording saved",recording=str(target),recording_url=f"/recordings/{target.name}")
        else:
            jobs[job_id].update(status="Failed",error="No recording was produced. The source may not support capture.")
    except Exception as e:
        jobs[job_id].update(status="Failed",error=str(e))

@app.get("/api/health")
def health():
    return {"ok":True,"ffmpeg":ffmpeg_ok(),"yt_dlp":shutil.which("yt-dlp") is not None}

@app.get("/api/jobs")
def list_jobs():
    safe=[]
    for k,v in jobs.items():
        safe.append({a:b for a,b in v.items() if a not in ("process",)})
    return safe[::-1]

@app.post("/api/upload")
async def upload(file: UploadFile=File(...)):
    ext=Path(file.filename or "video.mp4").suffix.lower()
    if ext not in (".mp4",".mov",".mkv",".webm"): raise HTTPException(400,"Upload MP4, MOV, MKV or WEBM.")
    jid=uuid.uuid4().hex[:10]; dest=UPLOADS/f"{jid}{ext}"
    with dest.open("wb") as f: shutil.copyfileobj(file.file,f)
    jobs[jid]={"id":jid,"name":file.filename,"status":"Queued","progress":0,"kind":"upload"}
    threading.Thread(target=process_file,args=(jid,dest),daemon=True).start()
    return {"id":jid,"status":"Queued"}

@app.post("/api/live/start")
def live_start(url: str=Form(...)):
    if not url.startswith(("https://","http://")): raise HTTPException(400,"Enter a valid HTTPS/HTTP URL.")
    jid=uuid.uuid4().hex[:10]
    jobs[jid]={"id":jid,"name":"Live capture","status":"Starting","progress":0,"kind":"live"}
    threading.Thread(target=capture_live,args=(jid,url),daemon=True).start()
    return {"id":jid,"status":"Starting"}

@app.post("/api/live/stop/{jid}")
def live_stop(jid: str):
    job=jobs.get(jid)
    if not job: raise HTTPException(404,"Job not found")
    proc=job.get("process")
    if proc and proc.poll() is None: proc.terminate()
    target=RECORDINGS/f"{jid}.mp4"
    if target.exists() and target.stat().st_size>0:
        jobs[jid].update(status="Recording saved",recording=str(target),recording_url=f"/recordings/{target.name}")
        return {"ok":True,"recording_url":f"/recordings/{target.name}"}
    return {"ok":True,"status":"Stop requested"}

@app.post("/api/process-recording/{jid}")
def process_recording(jid: str):
    job=jobs.get(jid)
    if not job or not job.get("recording"): raise HTTPException(404,"Recording not found")
    src=Path(job["recording"])
    new=uuid.uuid4().hex[:10]
    jobs[new]={"id":new,"name":src.name,"status":"Queued","progress":0,"kind":"recording"}
    threading.Thread(target=process_file,args=(new,src),daemon=True).start()
    return {"id":new,"status":"Queued"}

@app.get("/clips/{name}")
def get_clip(name: str):
    path=CLIPS/Path(name).name
    if not path.exists(): raise HTTPException(404,"Clip not found")
    return FileResponse(path,media_type="video/mp4",filename=path.name)

@app.get("/recordings/{name}")
def get_recording(name: str):
    path=RECORDINGS/Path(name).name
    if not path.exists(): raise HTTPException(404,"Recording not found")
    return FileResponse(path,filename=path.name)

app.mount("/",StaticFiles(directory=ROOT/"static",html=True),name="static")
